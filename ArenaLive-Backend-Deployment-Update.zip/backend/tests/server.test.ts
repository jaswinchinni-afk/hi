import request from "supertest";
import app from "../src/server";

describe("ArenaLive backend", () => {
  test("health endpoint works", async () => {
    const response = await request(app).get("/api/v1/health");
    expect(response.status).toBe(200);
    expect(response.body.status).toBe("healthy");
  });

  test("mock sports data is explicitly labeled", async () => {
    const response = await request(app).get("/api/v1/gateway/matches");
    expect(response.status).toBe(200);
    expect(response.body.meta.source).toBe("DEVELOPMENT_MOCK");
    expect(response.body.meta.live).toBe(false);
    expect(response.body.data[0].dataSource).toBe("DEVELOPMENT_MOCK");
  });

  test("AI rejects an empty prompt", async () => {
    const response = await request(app)
      .post("/api/v1/gateway/ai/ask")
      .send({});
    expect(response.status).toBe(400);
  });

  test("AI accepts a valid prompt", async () => {
    const response = await request(app)
      .post("/api/v1/gateway/ai/ask")
      .send({
        prompt: "Explain the match",
        context: { matchId: "m-101" }
      });
    expect(response.status).toBe(200);
    expect(response.body.data.answer).toContain("Development AI");
  });

  test("unknown routes return safe JSON", async () => {
    const response = await request(app).get("/api/v1/nope");
    expect(response.status).toBe(404);
    expect(response.body.error.message).toBe("Route not found");
  });
});
