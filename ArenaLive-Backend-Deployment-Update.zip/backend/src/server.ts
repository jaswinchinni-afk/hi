import express, { Request, Response, NextFunction, Router } from "express";
import cors from "cors";
import helmet from "helmet";
import { z } from "zod";
import dotenv from "dotenv";

dotenv.config();

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.coerce.number().int().positive().default(4000),
  DATABASE_URL: z.string().optional(),
  REDIS_URL: z.string().optional(),
  SPORTS_API_KEY: z.string().optional(),
  AI_PROVIDER_KEY: z.string().optional(),
  JWT_SECRET: z.string().optional(),
  VANGUARD_PROVIDER: z.string().default("mock")
}).superRefine((data, ctx) => {
  if (data.NODE_ENV === "production" && !data.JWT_SECRET?.trim()) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["JWT_SECRET"],
      message: "JWT_SECRET is required in production."
    });
  }
});

const parsedEnv = envSchema.safeParse(process.env);
if (!parsedEnv.success) {
  console.error("[ENV_CONFIG_ERROR]", parsedEnv.error.flatten());
  process.exit(1);
}
export const env = parsedEnv.data;

export interface MatchData {
  id: string;
  homeTeam: string;
  awayTeam: string;
  score: string;
  minute: string;
  xG: { home: number; away: number };
  dataSource: "DEVELOPMENT_MOCK";
  fetchedAt: string;
}

interface VanguardProvider {
  getLiveMatches(): Promise<MatchData[]>;
  queryAI(prompt: string, context?: unknown): Promise<string>;
}

class MockProvider implements VanguardProvider {
  async getLiveMatches(): Promise<MatchData[]> {
    return [{
      id: "m-101",
      homeTeam: "Real Madrid",
      awayTeam: "Man City",
      score: "2 - 1",
      minute: "74'",
      xG: { home: 1.84, away: 1.12 },
      dataSource: "DEVELOPMENT_MOCK",
      fetchedAt: new Date().toISOString()
    }];
  }

  async queryAI(prompt: string): Promise<string> {
    return `Development AI response for: "${prompt}" [SIMULATED DEVELOPMENT DATA]`;
  }
}

export class ProviderFactory {
  static getProvider(): VanguardProvider {
    if (env.VANGUARD_PROVIDER === "mock") {
      return new MockProvider();
    }
    throw new Error(
      `Unsupported or unconfigured provider type: "${env.VANGUARD_PROVIDER}".`
    );
  }
}

export function sanitizeLogData(value: unknown): unknown {
  if (!value || typeof value !== "object") return value;
  const sensitive = [
    "password", "apikey", "api_key", "token", "secret",
    "authorization", "cookie", "database_url", "redis_url"
  ];

  if (Array.isArray(value)) return value.map(sanitizeLogData);

  const output: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(value)) {
    if (sensitive.some(item => key.toLowerCase().includes(item))) {
      output[key] = "[REDACTED]";
    } else {
      output[key] = sanitizeLogData(val);
    }
  }
  return output;
}

export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  const requestId =
    req.header("x-request-id") ||
    `req-${Math.random().toString(36).slice(2, 10)}`;

  console.error("[ARENA_ERROR]", JSON.stringify({
    requestId,
    method: req.method,
    route: req.path,
    status: err?.statusCode || 500,
    message: err?.message || "Unknown error",
    body: sanitizeLogData(req.body),
    query: sanitizeLogData(req.query),
    stack: err?.stack
  }));

  const status = Number(err?.statusCode) || 500;

  res.status(status).json({
    success: false,
    error: {
      message: status === 500
        ? "Internal Server Error"
        : (err?.message || "Request failed")
    },
    requestId
  });
}

const aiAskSchema = z.object({
  prompt: z.string().trim().min(1).max(1000),
  context: z.record(z.unknown()).optional()
});

const healthRouter = Router();

healthRouter.get("/", (_req, res) => {
  res.json({
    success: true,
    status: "healthy",
    service: "arenalive-backend",
    environment: env.NODE_ENV,
    timestamp: new Date().toISOString()
  });
});

const gatewayRouter = Router();

gatewayRouter.get("/matches", async (_req, res, next) => {
  try {
    const matches = await ProviderFactory.getProvider().getLiveMatches();
    const mock = matches.some(
      match => match.dataSource === "DEVELOPMENT_MOCK"
    );

    res.json({
      success: true,
      data: matches,
      meta: {
        live: !mock,
        source: mock ? "DEVELOPMENT_MOCK" : "VERIFIED_PROVIDER",
        fetchedAt: matches[0]?.fetchedAt ?? null
      }
    });
  } catch (error) {
    next(error);
  }
});

gatewayRouter.post("/ai/ask", async (req, res, next) => {
  try {
    const validation = aiAskSchema.safeParse(req.body);

    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: {
          message: "Invalid request payload",
          details: validation.error.flatten()
        }
      });
    }

    const { prompt, context } = validation.data;
    const answer = await ProviderFactory
      .getProvider()
      .queryAI(prompt, context);

    res.json({
      success: true,
      data: { answer }
    });
  } catch (error) {
    next(error);
  }
});

export function createApp() {
  const app = express();

  app.disable("x-powered-by");
  app.use(helmet());
  app.use(cors());
  app.use(express.json({ limit: "100kb" }));

  app.use("/api/v1/health", healthRouter);
  app.use("/api/v1/gateway", gatewayRouter);

  app.use((_req, res) => {
    res.status(404).json({
      success: false,
      error: { message: "Route not found" }
    });
  });

  app.use(errorHandler);

  return app;
}

const app = createApp();

if (require.main === module) {
  app.listen(env.PORT, "0.0.0.0", () => {
    console.log(`ArenaLive backend listening on port ${env.PORT}`);
  });
}

export default app;
