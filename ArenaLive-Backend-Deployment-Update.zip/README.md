# ArenaLive Backend Deployment Update

## Upload these files to the backend repository

This is the cleaned backend foundation for ArenaLive.

### Render settings

Build command:
`npm install && npm run build`

Start command:
`npm start`

The server binds to `0.0.0.0` and uses the hosting provider's `PORT`.

### Health check

After deployment:

`/api/v1/health`

Expected response contains:

`"success": true`

and

`"status": "healthy"`

### Important data-status rule

The included provider is intentionally a development mock.

The API therefore returns:

`DEVELOPMENT_MOCK`

and:

`"live": false`

This is deliberate. ArenaLive must never label fake data as live.

A real sports provider must be implemented and configured before production live-match claims are enabled.

### Secrets

Never commit `.env` or real API keys to GitHub.

Use your hosting provider's environment-variable/secret settings.
